package com.example.plazoleta.ms_plazoleta.infrastructure.exceptions;

public class IllegalLogoException extends RuntimeException {
    public IllegalLogoException(String message) {
        super(message);
    }
}
