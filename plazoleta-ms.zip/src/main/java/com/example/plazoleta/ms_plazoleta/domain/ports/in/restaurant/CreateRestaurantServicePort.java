package com.example.plazoleta.ms_plazoleta.domain.ports.in.restaurant;

import com.example.plazoleta.ms_plazoleta.domain.model.Restaurant;

public interface CreateRestaurantServicePort {

    Restaurant execute(Restaurant user);



}
