package com.example.plazoleta.ms_plazoleta.domain.model;

public enum OrderStatus {
    PENDING,
    IN_PREPARATION,
    READY,
    DELIVERED,
    CANCELLED
}