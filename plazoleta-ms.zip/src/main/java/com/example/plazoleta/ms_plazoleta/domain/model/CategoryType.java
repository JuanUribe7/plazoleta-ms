package com.example.plazoleta.ms_plazoleta.domain.model;

public enum CategoryType {
    STARTER,
    DRINK,
    MAIN,
    DESSERT
}
