package com.example.plazoleta.ms_plazoleta.application.dto.request;

public class DishOrderRequestDto {
    private Long dishId;
    private Integer quantity;

    public Long getDishId() {
        return dishId;
    }

    public Integer getQuantity() {
        return quantity;
    }
}
