package com.example.plazoleta.ms_plazoleta.infrastructure.exceptions;

public class InvalidNitException extends RuntimeException {
    public InvalidNitException(String message) {
        super(message);
    }
}
