package com.example.plazoleta.ms_plazoleta.infrastructure.exceptions;

public class IllegalCategoryException extends RuntimeException {
    public IllegalCategoryException(String message) {
        super(message);
    }
}
